
#include "Activation.h"

/**
 * overloading the operator () by: applying a relu of softmax function
 * @param matrix the matrix we want to apply the function on
 * @return a new matrix after applying the fucntion on
 */
Matrix Activation::operator()(const Matrix &matrix)
{
    Matrix temp(matrix.getRows(), matrix.getCols());
    if(this->getActType() == Relu)
    {
        temp = _reluFunction(matrix);
    }

    else if(this->getActType() == Softmax)
    {
        temp = _softmaxFunction(matrix);
    }

    //todo maybe null

    return temp;
}

/**
 * get the activation type
 * @return  activation type
 */
ActivationType Activation::getActType()
{
    return this->_actType;
}

/**
 * constructor of act type
 * @param actType the act we want to construct activation from
 */
Activation::Activation(ActivationType actType)
{
    this->_actType = actType;
}

/**
 * a private function that applies the relu function
 * @param matrix the matrix we want to apply the function on
 * @return a new matrix after applying the function on
 */
Matrix Activation::_reluFunction(const Matrix& matrix)
{
    Matrix temp(matrix.getRows(), matrix.getCols());
    for (int i = 0; i < matrix.getRows(); i++)
    {
        for (int j = 0; j < matrix.getCols(); j++)
        {
            if(matrix(i, j) >= 0.0f)
            {
                temp(i, j) = matrix(i, j);
            }
        }
    }
    return temp;
}

/**
 * a private function that applies the softmax function
 * @param matrix the matrix we want to apply the function on
 * @return a new matrix after applying the function on
 */
Matrix Activation::_softmaxFunction(const Matrix& matrix)
{
    Matrix temp(matrix.getRows(), matrix.getCols());
    float answer = 0.0f;
    for (int i = 0; i < matrix.getRows(); i++)
    {
        answer += (std::exp(matrix[i]));
    }
    for (int j = 0; j < matrix.getRows(); j++)
    {
        temp[j] = (1.0f/ answer)*(std::exp(matrix[j])) ;  //todo maybe 1.0f/ans
    }
    return temp;
}
