//MlpNetwork.h

#ifndef MLPNETWORK_H
#define MLPNETWORK_H

#include "Matrix.h"
#include "Digit.h"
#include "Dense.h"

#define MLP_SIZE 4

const MatrixDims imgDims = {28, 28};
const MatrixDims weightsDims[] = {{128, 784}, {64, 128}, {20, 64}, {10, 20}};
const MatrixDims biasDims[]    = {{128, 1}, {64, 1}, {20, 1},  {10, 1}};

// Insert MlpNetwork class here...

/**
 * a  MlpNetwork class
 */
class MlpNetwork
{
    public:

        /**
         * constructor of the network with given weights and biases
         * @param weights the weights
         * @param biases the biases
         */
        MlpNetwork(Matrix weights[], Matrix biases[]);


        /**
        * apply the Dense on a giving matrix and get athe result of the nubmer
        * @param matrix the matrix we want to check the number in it
        * @return the number with the highest probability
        */
        Digit operator()(const Matrix& matrix);

    private:
        Matrix weights[MLP_SIZE];
        Matrix biases[MLP_SIZE];
};

#endif // MLPNETWORK_H
