#include "Matrix.h"

#define ERROR_MULTIPLICATION "Error: rows and cols aren't the same size"
#define ERROR_NEGATIVE "Error: the Input is negative"
#define ERROR_SUM "Error: both matrix not same size"
#define ERROR_IS "Error: input stream got problems"

/**
 * default constructor of matrix it will be 1x1 size
 */
Matrix::Matrix() : Matrix(1,1)
{
}

/**
 * construct a matrix with the given size of rows and cols
 * @param rows the rows of the matrix
 * @param cols the cols of the matrix
 */
Matrix::Matrix(int rows, int cols)
{
    if(rows <= 0 || cols <= 0)
    {
        std::cerr << ERROR_NEGATIVE << std::endl;
        exit(EXIT_FAILURE);
    }
    this->_rows = rows;
    this->_cols = cols;
    this->_matrix = new float[rows * cols];
	for (int i = 0; i < rows * cols; ++i)
	{
		(*this)[i] = 0;
	}
//    this->_matrix = {}; //todo maybe add size.
}

/**
 * copy constructor, build a matrix from a given matrix
 * @param matrix the matrix we want to copy it to another matrix
 */
Matrix::Matrix (Matrix const &matrix)
{
    this->_rows = matrix.getRows();
    this->_cols = matrix.getCols();
    int size = _rows * _cols;
//    delete[] this->_matrix;
    this->_matrix = new float[size];
    for (int i = 0; i < size; i++)
    {
        this->_matrix[i] = matrix[i];
    }
}

/**
 * destructor of Matrix
 */
Matrix::~Matrix()
{
    delete[] this->_matrix;
}

/**
 * get rows of the matrix
 * @return rows
 */
int Matrix::getRows() const
{
    return _rows;
}

/**
 * get columns of the matrix
 * @return columns
 */
int Matrix::getCols() const
{
    return _cols;
}

/**
 * print the matrix
 */
void Matrix::plainPrint() const
{
    for (int i = 0; i < this->getRows(); i++)
    {
        for (int j = 0; j < this->getCols(); j++)
        {
            std::cout << (*this)(i, j) << " ";
        }
        std::cout << std::endl; //printLine
    }
}

/**
 * transform the matrix into a column vector.
 */
Matrix &Matrix::vectorize()
{
    this->_setRows(this->getRows() * (this->getCols()));
    this->_setCols(1);
    return (*this);
}


//Private functions
/**
 * private function to set the rows of matrix
 * @param row the rows we want to change the matrix's rows into
 */
void Matrix::_setRows(int row)
{
    this->_rows = row;
}

/**
 * private function to set the cols of matrix
 * @param col the cols we want to change the matrix's cols into
 */
void Matrix::_setCols(int col)
{
    this->_cols = col;
}


//operators
/**
 * overload the = operator to :assign a given matrix to the current matrix
 * @param other the given matrix we want to take its values
 * @return the assigned matrix with the values of the given matrix (other)
 */
Matrix& Matrix::operator=(const Matrix &other)
{
    //if the same then return this without changing.
    if (this == &other)
    {
        return (*this);
    }

    this->_setRows(other.getRows());
    this->_setCols(other.getCols());
    delete[] this->_matrix;
    this->_matrix = new float [this->getRows() * this->getCols()];
    for (int i = 0; i < other.getCols() * other.getRows(); ++i)
    {
        this->_matrix[i] = other[i];
    }
    return *this;
}

/**
 * overload the * operator to :multiply two matrices
 * @param other the given matrix we want to multiply
 * @return a new matrix equals the multiplication of the two matrices
 */
Matrix Matrix::operator*(const Matrix &other)
{
    if(this->getCols() != other.getRows())
    {
        std::cerr << ERROR_MULTIPLICATION << std::endl;
        exit(EXIT_FAILURE);
    }

    int newMRows = this->getRows();
    int newMCols = other.getCols();
    Matrix mulRes = Matrix(newMRows, newMCols);
    for (int i = 0; i < newMRows; i++)
    {
        for (int j = 0; j < newMCols; j++)
        {
            for(int k = 0; k < this->getCols(); k++)
            {
                mulRes(i, j) += (*this)(i,k) * other(k, j);
            }
        }
    }
    return mulRes;
}

/**
 * overload the + operator to :add two matrices
 * @param other the given matrix we want to add
 * @return a new matrix equals the multiplication of the two matrices
 */
Matrix Matrix::operator+(const Matrix &other)
{
    int rows = this->getRows();
    int cols = this->getCols();

    if(cols != other.getCols() || rows != other.getRows())
    {
        std::cerr << ERROR_SUM << std::endl;
        exit(EXIT_FAILURE);
    }
    Matrix mulMatrix = Matrix(rows, cols);
    for(int i = 0; i < rows * cols; i++)
    {
        mulMatrix[i] = (*this)[i] + other[i];
    }

    return mulMatrix;

}

/**
 * overload the += operator to :add a matrix to the current matrix
 * @param other the given matrix we want to add
 * @return the current matrix added to it the other matrix
 */
Matrix &Matrix::operator+=(const Matrix &other)
{
    int rows = this->getRows();
    int cols = this->getCols();

    if(cols != other.getCols() || rows != other.getRows())
    {
        std::cerr << ERROR_SUM << std::endl;
        exit(EXIT_FAILURE);
    }

    for(int i = 0; i < rows*cols; i++)
    {
        (*this)[i] += other[i];
    }
    return *this;
}

/**
 * overload the [] operator to : return reference of the value of the index of the matrix
 * @param indexI the index of the matrix we want to return the value of it in matrix
 * @return the reference to the index in matrix
 */
float &Matrix::operator[](const int indexI) const
{
    if(indexI < 0 || indexI >= this->getRows() * this->getCols())
    {
        std::cerr << ERROR_NEGATIVE << std::endl;
        exit(EXIT_FAILURE);
    }
    return this->_matrix[indexI];
}

/**
 * overload the () operator to : return reference of the value of the given indexes of the matrix
 * @param indexI the index of the matrix represents the rows
 * @param indexJ the index of the matrix represents the cols
 * @return the reference to the indexes in matrix
 */
float &Matrix::operator()(const int indexI, const int indexJ) const
{
    if(indexI < 0 || indexJ < 0 || indexI >= this->getRows() || indexJ >= this->getCols())
    {
        std::cerr << ERROR_NEGATIVE << std::endl;
        exit(EXIT_FAILURE);
    }
    return this->_matrix[(indexI * this->getCols() + indexJ)];
}


//std::ostream &Matrix::operator<<(std::ostream &os)
//{
//    std::cout << std::endl; //printLine
//    for (int i = 0; i < this->getRows(); i++)
//    {
//        for (int j = 0; j < this->getCols(); j++)
//        {
//            if((*this)(i,j) <= 0.1)
//            {
//                std::cout << "  ";
//            } else
//            {
//                std::cout << "**";
//            }
//        }
//        std::cout << std::endl; //printLine
//    }
//    std::cout << std::endl; //printLine
//
//    std::cout << "Mlp result: "<< <res> << " at probability: " << <prob> << std::endl; //todo get prob mlp
//}

//std::ostream &operator<<(std::ostream &os, const Matrix& matrix)
//{
//    os << std::endl; //printLine
//    for (int i = 0; i < matrix.getRows(); i++)
//    {
//        for (int j = 0; j < matrix.getCols(); j++)
//        {
//            if(matrix(i, j) <= 0.1f)
//            {
//                os << "  ";
//            } else
//            {
//                os << "**";
//            }
//        }
//        os << std::endl; //printLine
//    }
//    os << std::endl; //printLine
//    return os;
////    os << "Mlp result: "<< <res> << " at probability: " << <prob> << std::endl; //todo get prob mlp
//}


/**
 * overload the << operator to : add the way to print into the os
 * @param os the output stream
 * @return the output stream
 */
std::ostream &operator<<(std::ostream &os, const Matrix& matrix)
{
    for (int i = 0; i < matrix.getRows(); i++)
    {
        for (int j = 0; j < matrix.getCols(); j++)
        {
            if(matrix(i, j) <= 0.1f)
            {
                os << "  ";
            }
            else
            {
                os << "**";
            }
        }
        os << std::endl; //printLine
    }
    return os;
}

/**
 * overload the >> operator to : fill the matrix with input stream
 * @param input the input stream we want to fill the matrix with
 * @return an input stream
 */
std::istream &operator>>(std::istream &input, Matrix &matrix)
{

    for (int i = 0; i < matrix.getRows()*matrix.getCols(); i++)
    {
        input.read((char *) &matrix[i], sizeof(float));
        if(!input || !input.good())
        {
            std::cerr << ERROR_IS << std::endl;
            exit(EXIT_FAILURE);
        }
    }
    if (input.peek() != EOF)
    {
        std::cerr << ERROR_IS << std::endl;
        exit(EXIT_FAILURE);
    }
    return input;
}

/**
 * multiply a matrix with scalar from the right (matrix * scalar)
 * @param scalar the scalar we want to multiply the matrix with
 * @param left the matrix on the left of the scalar
 * @return a new matrix multiplied with scalar
 */
Matrix operator*(const Matrix& left, const float& scalar)
{
    Matrix mulMatrix = Matrix(left.getRows(),left.getCols());
    int matrixSize = left.getCols()*left.getRows();
    for (int i = 0; i < matrixSize; i++)
    {
        mulMatrix[i] = (left[i] * scalar);
    }
    return mulMatrix;
}

/**
 * multiply a matrix with scalar from the left (scalar * matrix)
 * @param scalar the scalar we want to multiply the matrix with
 * @param right the matrix on the right of the scalar
 * @return a new matrix multiplied with scalar
 */
Matrix operator*(const float& scalar, const Matrix& right)
{
    //there is no different multiplying matrix in the right or left with scalar
    return (right * scalar);
}


