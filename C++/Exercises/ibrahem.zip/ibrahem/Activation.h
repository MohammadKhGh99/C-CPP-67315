//Activation.h
#ifndef ACTIVATION_H
#define ACTIVATION_H

#include "Matrix.h"
#include <cmath>

/**
 * @enum ActivationType
 * @brief Indicator of activation function.
 */
enum ActivationType
{
    Relu,
    Softmax
};

// Insert Activation class here...
/**
 * an activation class
 */
class Activation
{
    public:

        /**
         * constructor of act type
         * @param actType the act we want to construct activation from
         */
        Activation(ActivationType actType);

        /**
        * get the activation type
        * @return  activation type
        */
        ActivationType getActType();

        /**
        * overloading the operator () by: applying a relu of softmax function
        * @param matrix the matrix we want to apply the function on
        * @return a new matrix after applying the fucntion on
        */
        Matrix operator()(const Matrix& matrix);

    private:
        /**
         * a private function that applies the relu function
         * @param matrix the matrix we want to apply the function on
         * @return a new matrix after applying the function on
         */
        static Matrix _reluFunction(const Matrix& matrix);

        /**
         * a private function that applies the softmax function
         * @param matrix the matrix we want to apply the function on
         * @return a new matrix after applying the function on
         */
        static Matrix _softmaxFunction(const Matrix& matrix);
        ActivationType _actType;
};


#endif //ACTIVATION_H
