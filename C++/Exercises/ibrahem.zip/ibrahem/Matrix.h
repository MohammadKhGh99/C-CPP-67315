// Matrix.h

#ifndef MATRIX_H
#define MATRIX_H

#include <iostream>

/**
 * @struct MatrixDims
 * @brief Matrix dimensions container
 */
typedef struct MatrixDims
{
    int rows, cols;
} MatrixDims;

// Insert Matrix class here...
/**
 * a matrix class
 */
class Matrix
{
public:
    /**
     * default constructor of matrix it will be 1x1 size
     */
    Matrix();

    /**
     * construct a matrix with the given size of rows and cols
     * @param rows the rows of the matrix
     * @param cols the cols of the matrix
     */
    Matrix(int rows, int cols);

    /**
     * copy constructor, build a matrix from a given matrix
     * @param obj the matrix we want to copy it to another matrix
     */
    Matrix (Matrix const &obj);

    /**
     * destructor of Matrix
     */
    ~Matrix();

    /**
     * get rows of the matrix
     * @return rows
     */
    int getRows() const;

    /**
     * get columns of the matrix
     * @return columns
     */
    int getCols() const;

    /**
     * print the matrix
     */
    void plainPrint() const;

    /**
     * transform the matrix into a column vector.
     */
    Matrix &vectorize();

    /**
     * assign a given matrix to the current matrix
     * @param other the given matrix we want to take its values
     * @return the assigned matrix with the values of the given matrix (other)
     */
    Matrix& operator=(const Matrix& other);

    /**
     * overload the * operator to :multiply two matrices
     * @param other the given matrix we want to multiply
     * @return a new matrix equals the multiplication of the two matrices
     */
    Matrix operator*(const Matrix& other);

    /**
     * overload the + operator to :add two matrices
     * @param other the given matrix we want to add
     * @return a new matrix equals the multiplication of the two matrices
     */
    Matrix operator+(const Matrix& other);

    /**
     * overload the += operator to :add a matrix to the current matrix
     * @param other the given matrix we want to add
     * @return the current matrix added to it the other matrix
     */
    Matrix& operator+=(const Matrix& other);

    /**
     * overload the [] operator to : return reference of the value of the index of the matrix
     * @param indexI the index of the matrix we want to return the value of it in matrix
     * @return the reference to the index in matrix
     */
    float& operator[](int indexI) const;

    /**
     * overload the () operator to : return reference of the value of the given indexes of the matrix
     * @param indexI the index of the matrix represents the rows
     * @param indexJ the index of the matrix represents the cols
     * @return the reference to the indexes in matrix
     */
    float& operator()(int indexI, int indexJ) const;

    /**
     * overload the << operator to : add the way to print into the os
     * @param os the output stream
     * @return the output stream
     */
    friend std::ostream& operator<<(std::ostream& os, const Matrix& matrix);

    /**
     * overload the >> operator to : fill the matrix with input stream
     * @param input the input stream we want to fill the matrix with
     * @return an input stream
     */
    friend std::istream& operator>>(std::istream& input, Matrix &matrix);


private:

    /**
     * private function to set the rows of matrix
     * @param row the rows we want to change the matrix's rows into
     */
    void _setRows(int row);

    /**
     * private function to set the cols of matrix
     * @param col the cols we want to change the matrix's cols into
     */
    void _setCols(int col);


    int _rows, _cols;
    float *_matrix;
};

/**
 * multiply a matrix with scalar from the right (matrix * scalar)
 * @param scalar the scalar we want to multiply the matrix with
 * @param left the matrix on the left of the scalar
 * @return a new matrix multiplied with scalar
 */
Matrix operator*(const Matrix& left, const float& scalar);

/**
 * multiply a matrix with scalar from the left (scalar * matrix)
 * @param scalar the scalar we want to multiply the matrix with
 * @param right the matrix on the right of the scalar
 * @return a new matrix multiplied with scalar
 */
Matrix operator*(const float& scalar, const Matrix& right);

#endif //MATRIX_H
