#include "Dense.h"

/**
 * a constructor of Dense,
 * @param w - given weights
 * @param bias - given bias
 * @param actType - given activationType
 */
Dense::Dense(const Matrix& w, const Matrix& bias, ActivationType actType)
{
    this->_actType = actType;
    this->_bias = bias;
    this->_weight = w;
}

/**
 * get weight of Dense
 * @return weight of Dense
 */
Matrix Dense::getWeight() const
{
    return this->_weight;
}

/**
 * get bias of Dense
 * @return bias of Dense
 */
Matrix Dense::getBias() const
{
    return this->_bias;
}

/**
 * get activation type of Dense
 * @return activation type of Dense
 */
Activation Dense::getActivation() const
{
    //todo maybe check if its null or not..
    return {this->_actType};
}

/**
 * applying the  activationType(Weight · matrix + bias) on a giving _matrix
 * @param matrix - the matrix we want to apply the function to
 * @return the result of the function (it will be matrix (vector))
 */
Matrix Dense::operator()(const Matrix &matrix)const
{

    return (this->getActivation())((this->getWeight() * matrix) + this->getBias());

}
