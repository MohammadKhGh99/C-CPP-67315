
#ifndef DENSE_H
#define DENSE_H


#include "Matrix.h"
#include "Activation.h"

/**
 * a Dense class
 */
class Dense
{
public:

    /**
     * a constructor of Dense,
     * @param w - given weights
     * @param bias - given bias
     * @param actType - given activationType
     */
    Dense(const Matrix& w, const Matrix& bias, ActivationType actType);

    /**
     * get weight of Dense
     * @return weight of Dense
     */
    Matrix getWeight() const;

    /**
     * get bias of Dense
     * @return bias of Dense
     */
    Matrix getBias() const;

    /**
     * get activation type of Dense
     * @return activation type of Dense
     */
    Activation getActivation() const;

    /**
     * applying the  activationType(Weight · matrix + bias) on a giving _matrix
     * @param matrix - the matrix we want to apply the function to
     * @return the result of the function (it will be matrix (vector))
     */
    Matrix operator()(const Matrix& matrix)const ;

private:
    Matrix _weight , _bias;
    ActivationType _actType;
};


#endif //DENSE_H
