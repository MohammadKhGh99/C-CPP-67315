#include "MlpNetwork.h"

/**
 * constructor of the network with given weights and biases
 * @param weights the weights
 * @param biases the biases
 */
MlpNetwork::MlpNetwork(Matrix *weights, Matrix *biases)
{
    //this is valgrind shit!! fix it, like do private and you know..
    for(int i = 0; i < MLP_SIZE; i++)
    {
    	this->weights[i]=weights[i];
        this->biases[i]=biases[i];
    }

}

/**
 * apply the Dense on a giving matrix and get athe result of the nubmer
 * @param matrix the matrix we want to check the number in it
 * @return the number with the highest probability
 */
Digit MlpNetwork::operator()(const Matrix &matrix)
{
    // apply four activation types on the _matrix
    Matrix matrixResult = Dense(this->weights[0], this->biases[0], Relu)(matrix);
    matrixResult = Dense(this->weights[1], this->biases[1], Relu)(matrixResult);
    matrixResult = Dense(this->weights[2], this->biases[2], Relu)(matrixResult);
    matrixResult = Dense(this->weights[3], this->biases[3], Softmax)(matrixResult);


    //find the number with highest probability:
    Digit digit = {0, matrixResult[0]};


    for (int i = 0; i < 10; i++)
    {
        if (digit.probability < matrixResult[i])
        {
            digit.value = i;
            digit.probability = matrixResult[i];
        }
    }
    return digit;

}
