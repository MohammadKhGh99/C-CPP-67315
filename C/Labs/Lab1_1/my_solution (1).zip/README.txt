In this lab, you are requested to write a program that behaves as follows:
> If the input is 1 – print Hello World!
> Else if the input is 2 – print Welcome to C!
> Else print nothing.
You are provided with a wrong solution, and your goal is to fix it according to theh instructions.
The solution file and the submission is located under Lab C 1 in the moodle.
If your fix passes the pre-submission, you get a full score for this lab.
* Submit a tar named "file includes only the not compiled code file (main.c) 
